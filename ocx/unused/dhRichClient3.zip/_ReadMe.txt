
The dhRichClient3-Toolset is placed in the Public Domain
and is thought mainly as a feature-rich vbRuntime-enhancement,
which aims to lower the dependencies into the COM-based
MS-ToolStack (it  contains replacements for e.g. DAO/ADO/JET,
MS-XML, DCOM, the Scripting-Dictionary, etc.). 

It also offers regfree Loading/Instancing-capabilities
for ActiveX-Dlls and it can also make ActiveX-Exes obsolete,
due to support for a new, easy to use Threading-approach, 
which works with Named-Pipes under the hood, and can 
therefore not only be used for multiple Threads "InProcess",
but also for cross-process-access to Thread-Objects, which
are now (always) created regfree, directly from dedicated
COM-/AX- Dlls. These ThreadObjects can have multiple clients
connected to them, so you can also use them for Singleton-
scenarios, which one formerly had to implement in VB-Classic
over ActiveX-Exes which got a ThreadPool=1-setting.

The toolset can be used also "commercially" and it currently consists of:
dhRichClient3.dll (COM-Dll - needs registering on your developer-machine)
DirectCOM.dll (Windows-Standard-Dll - no registering needed)
sqlite36_engine.dll (3.6.14, Windows-Standard-Dll - no registering needed)
(a cairo-wrapper-AX-Dll and a new VB-WidgetSet are coming soon)

Most of the newer functionalities (classes) in this toolset 
do require W2K or higher to work - please understand that -
since I want to "move fast" with these class-helpers and
also with the new (unicode-capable) widgetset over the 
next years, I had to "draw a line" somewhere.



Installation on your Developer-Machine:
Please place the toolset on your local HardDrive
(e.g. in a Folder C:\dhRichClient3\..)
and register the AX-Dll (dhRichClient3.dll) there
(I've included a simple Batch-File 'register.bat'
 for that purpose, in case you don't want to use your
 own registration-helpers (or regsvr32 on a console) -
 and also to support Vista-users a bit better, which
 then would have to run register.bat in Admin-Mode
 by right-clicking on that file per context-menu)
 

Other than in former versions, this version-3 should
not need a separate placement of the two Std-Dlls
(DirectCOM.dll and sqlite36_engine.dll) in \System32\
anymore on your developer-machine, but doing so anyway 
would do "no harm"...


Redistribution (and some comments about regfree usage):
Most of the Demos in:
www.datenhaus.de/Downloads/dhRichClient3-Demo.zip
make use of the Toolset-Classes in a "normal way"
as long as they are executed from within the VB-IDE 
(meaning, with the usual registry-lookup for a 
"normally registered" COMponent, forced by using the 
 New-Operator for Object-instancing).

If the "RunningInIDE()-check" shows, that a Demo
is running from a Binary (usually an "Exe"), then
the Toolset-Classes are tried to be instantiated
regfree - the lookup for the Framework-Dlls is done
in this case over the App.Path, so therefore you 
could place a copy of the three Framework-Dlls 
beside the Exe, if the Demo-Folder does not contain 
them already in this way. Nonetheless the Demos also
work compiled Binaries if you don't copy the Framework-
Dlls to the Demo-Folder - in this case a Demo will ask,
if you want to use the registry-based Instancing.

You could copy that approach (which is ensured over
a small *.bas-module, called 'modFactory.bas' also for
your own "real-world-projects". And as already said
above - the regfree-loading DirectCOM.dll offers,
is not restricted to the classes of dhRichClient3.dll -
the regfree-approach will work as well against your own
ActiveX-Dlls.
You can read additional notes about the factory-helperobjects
from modFactory.bas in an additional _ReadMe_Factory.txt
which is also included in this package. 

The dhRichClient3.dll depends on sqlite36_engine.dll and
DirectCOM.dll and cannot be used "standalone" - though,
the other two Std-Dlls of the framework can.
(so, if you need only the regfree-support from DirectCOM.dll,
you can distribute only this small Dll, if you want that.

Ok, finally a note regarding UPX - two of the framework-dlls
(dhRichClient3.dll and sqlite36_engine.dll) are UPX-compressed,
to keep their Download-Size low - and to "speedup" their loading
somewhat.
If you are not a "fan of UPX" (e.g. some "cheaper" Virus-Scanners 
are somewhat "picky" about UPXed binaries), then simply De-UPX them
if you want. I've included the UPX.exe and an appropriate
BatchFile for that purpose.
dhRichClient3.dll will then expand to ca. 1.4MB -
and sqlite36_engine.dll to ca. 540kB.


Available dhRichClient3-functionality (-Classes):

SQLite-Classes - an ADO-like Replacement based on the great sqlite-engine (www.sqlite.org)
SimpleXML-Classes - an unicode-aware XML-Parser with DOM and SAX-Support
cSortedDictionary - superfast alternative to the Scripting.Dictionary
cCollection - a nearly similar approach as above, but compatible to the VB-Collection
Report-Classes - an enhanced-metafile-based WYSIWYG-Reporting-engine 
Socket-Classes - TCP-Server and -Client-Classes (an alternative to the winsock.ocx)
cCrypt - strong-encryption-, hashing-, encoding- and compression-stuff
cEventCollection - Eventsupport for COM-LateBound-Objects in a centralized sink
OpenOfficeEmbed-Classes - embed OpenOffice-Documents into your VB-Forms
cFormula - a Formula-Evaluator, which supports Variables, Arrays and Objects in the Eval-Term
cTimer - a classbased replacement for the VB-Timer
RPC-Classes - the Client- *and* Serverpart (including the ThreadPool) for a fast DCOM-alternative 
DC, DIB and DDB-Classes - GDI-encapsulation with support for e.g. ByteArrayBased (Alpha-)Icon-loading, AlphaBlending etc.
cRegFree - support for the new pipe-based Threading-enhancements and regfree Class-Loading
cConstructor - an instantiation-helper, which offers Optional Init-Params for most Classes
cFactory - the "main-entry-point" into the framework, which contains the two classes above


Have fun!

Olaf Schmidt (os@datenhaus.de)
(in Mar/2009)

