
The modules modFactory.bas and modRC3.bas are basically
Instantiation-helpers for all the RichClient3-Classes.
More than that they can also ensure a regfree-loading
of the Toolset-Classes.

If you don't need the regfree-loading-capabilities, the
toolset hereby offers (implemented in the factory-modules),
then you can of course also load all the RichClient-Classes
in a normal way within your own VB-Apps - just put a reference
to dhRichClient3 into your VB-Project and use VBs New-Operator
for direct instancing.

modFactory.bas was kept a bit simpler and is included
(and used) also within the RichClient3-Demos:
www.datenhaus.de/Downloads/dhRichClient3-Demo.zip

In case the functionality of my more Demo-oriented 
module is not enough for your purposes - e.g. if you 
want more flexibility with the Toolset-Paths, then 
please take a look at Ulrich Korndoerfers enhanced 
Loader-Module, which offers a few more "degrees of 
freedom" and also a more extensive reporting in case 
something went wrong with the loader- and instantiation-
mechanisms.

Also check out his site: 
http://www.prosource.de/Downloads/indexe.html

Ulrichs module is called modRC3.bas and included
in this Toolset-Folder. Please read his extensive 
comments in modRC3.bas, on how to use his module.


Olaf Schmidt
