How to connect etc.


create an icon with properties


single user
target C:\dlc\bin\prowin32.exe -pf sportsu.pf
startin c:\wddlc\sports

thin client
target C:\dlc\bin\prowin32.exe -pf sportsremote.pf
startin c:\wddlc\sports
change appsrv.pf for youre appservername etc.

sports.ini contains appserver names
and parameter file names
